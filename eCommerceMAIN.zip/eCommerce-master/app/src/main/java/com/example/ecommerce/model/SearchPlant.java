package com.example.ecommerce.model;
//
//import android.os.Bundle;
//import android.widget.EditText;
//import android.widget.ImageButton;
//
//import androidx.activity.EdgeToEdge;
//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.example.ecommerce.Adapter.PlantAdapter;
//import com.example.ecommerce.Adapter.SearchPlantRecyclerAdapter;
//import com.example.ecommerce.R;
//import com.example.ecommerce.Utils.FirebaseUtils;
//import com.firebase.ui.firestore.FirestoreRecyclerOptions;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//import com.google.firebase.firestore.Query;
//
//import java.util.ArrayList;
//import java.util.List;
//
public class SearchPlant extends AppCompatActivity {
//
//    EditText searchInput;
//    ImageButton backButton;
//    DatabaseReference database;
//    ImageButton searchButton;
//    RecyclerView recyclerView;
//    ArrayList<Produto> plantlist;
//    PlantAdapter adapter;
//    SearchPlantRecyclerAdapter recyclerAdapter;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_search_plant);
//
//            searchInput = findViewById(R.id.search_input);
//            searchButton = findViewById(R.id.search_button_);
//            backButton = findViewById(R.id.back_button);
//            recyclerView = findViewById(R.id.search_recycler);
//
//            database = FirebaseDatabase.getInstance().getReference("Plantas");
//            recyclerView.setHasFixedSize(true);
//            recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//            plantlist = new ArrayList<>();
//            adapter = new PlantAdapter(plantlist, this);
//            recyclerView.setAdapter(adapter);

//            database.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//
//                        Produto produto = dataSnapshot.getValue(Produto.class);
//                        plantlist.add(produto);
//                 }
//                    adapter.notifyDataSetChanged();
//                }
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//                }
//            });


//            searchInput.requestFocus();
//
//            backButton.setOnClickListener(v -> {
//                getOnBackPressedDispatcher().onBackPressed();
//            });
//
//            searchButton.setOnClickListener(v -> {
//                String searchTerm = searchInput.getText().toString();
//                if (searchTerm.isEmpty() || (searchTerm.length()<3)){
//                    searchInput.setError("Pesquisa Inválida!");
//                    return;
//                }
//                setupSearchRecycler(searchTerm);
           // });
        }

//        public void setupSearchRecycler (String searchTerm){

//       Query query = FirebaseUtils.allPlantCollectionReference()
//               .whereGreaterThanOrEqualTo("plantas",searchTerm);
//
//       FirestoreRecyclerOptions<Produto> options = new FirestoreRecyclerOptions.Builder<Produto>()
//               .setQuery(query,Produto.class).build();
//
//        recyclerAdapter = new SearchPlantRecyclerAdapter(options,getApplicationContext());
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setAdapter(recyclerAdapter);
//        recyclerAdapter.startListening();
//        }

//    @Override
//    protected void onStart() {
//        super.onStart();
//        if (recyclerAdapter != null){
//            recyclerAdapter.startListening();
//        }
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        if (recyclerAdapter != null){
//            recyclerAdapter.stopListening();
//        }
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        if (recyclerAdapter != null){
//            recyclerAdapter.startListening();
//        }
//  }
//}