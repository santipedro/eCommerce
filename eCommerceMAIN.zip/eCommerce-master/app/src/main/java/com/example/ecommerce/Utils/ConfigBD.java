package com.example.ecommerce.Utils;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

    public class ConfigBD {

        private static FirebaseAuth auth; // Se cria a variável da autênticação.

        public static FirebaseAuth FirebaseAuthentic(){
            if(auth ==null){
                auth =FirebaseAuth.getInstance(); // Se Auth for nulo, há uma nova instância.
            }
            return auth;
        }
    }

