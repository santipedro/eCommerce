package com.example.ecommerce;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginForm extends AppCompatActivity {

    // Declaração de variáveis para os componentes da tela de login
    private TextView tela_cadastro;
    private TextView forgot_pass;
    private EditText edit_email, edit_senha;
    private Button button_entrar;
    private ProgressBar progressbar;
    // Array de mensagens para serem exibidas em caso de erro ou sucesso
    String[] messages = {"Preencher todos os campos", "Login concluído com sucesso"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sign);

        // Inicializa os componentes da tela de login
        IniciarCadastro();

        // Listener para o botão de cadastro
        tela_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redireciona para a tela de cadastro
                Intent intent = new Intent(LoginForm.this, CadastroForm.class);
                startActivity(intent);
                finish();
            }
        });

        // Listener para o botão de esqueci a senha
        forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redireciona para a tela de esqueci a senha
                Intent intent = new Intent(LoginForm.this, ForgotPass.class);
                startActivity(intent);
                finish();
            }
        });

        // Listener para o botão de entrar
        button_entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtém os valores dos campos de email e senha
                String email = edit_email.getText().toString();
                String senha = edit_senha.getText().toString();

                // Verifica se os campos estão vazios
                if (email.isEmpty() || senha.isEmpty()) {
                    // Exibe uma mensagem de erro se os campos estiverem vazios
                    Snackbar snackbar = Snackbar.make(v, messages[0], Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                } else {
                    // Chama o método de autenticação de usuário
                    AuthUsers(v);
                }
            }
        });
    }

    // Método de autenticação de usuário
    private void AuthUsers(View view) {
        // Obtém os valores dos campos de email e senha
        String email = edit_email.getText().toString();
        String senha = edit_senha.getText().toString();

        // Realiza a autenticação de usuário com o Firebase
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Exibe a ProgressBar e redireciona para a tela principal após 3 segundos
                            progressbar.setVisibility(View.VISIBLE);
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    TelaPrincipal();
                                }
                            }, 3000);
                        } else {
                            // Trata o erro de autenticação
                            String error;
                            try {
                                throw task.getException();
                            } catch (Exception e) {
                                error = "Usuário ou Senha Incorretos!";
                            }
                            // Oculta a ProgressBar e exibe uma mensagem de erro
                            progressbar.setVisibility(View.GONE);
                            Snackbar snackbar = Snackbar.make(view, error, Snackbar.LENGTH_SHORT);
                            snackbar.setBackgroundTint(Color.WHITE);
                            snackbar.setTextColor(Color.BLACK);
                            snackbar.show();
                        }
                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Verifica se já existe um usuário logado no APP
        FirebaseUser userAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (userAtual!= null) {
            // Redireciona para a tela principal se o usuário estiver logado
            TelaPrincipal();
        }
    }

    // Método para redirecionar para a tela principal
    private void TelaPrincipal() {
        Intent intent = new Intent(LoginForm.this, TelaPrincipal.class);
        startActivity(intent);
        finish();
    }

    //Método para direcionar à tela de esquecer senha
    private void ForgotPass() {
        Intent intent = new Intent(LoginForm.this, ForgotPass.class);
        startActivity(intent);
        finish();
    }

    private void IniciarCadastro() {
        forgot_pass = findViewById(R.id.forgot_pass);
        tela_cadastro = findViewById(R.id.textelacastrar);
        edit_email = findViewById(R.id.edit_email);
        edit_senha = findViewById(R.id.edit_senha);
        button_entrar = findViewById(R.id.button_entrar);
        progressbar = findViewById(R.id.progressbar);
    }