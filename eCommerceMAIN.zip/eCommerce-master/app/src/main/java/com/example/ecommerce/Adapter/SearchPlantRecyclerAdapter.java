package com.example.ecommerce.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.model.Produto;
import com.example.ecommerce.model.SearchPlant;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

//public class SearchPlantRecyclerAdapter extends FirestoreRecyclerAdapter <Produto, SearchPlantRecyclerAdapter.SearchModelViewHolder> {
//    Context context;
//    public SearchPlantRecyclerAdapter(@NonNull FirestoreRecyclerOptions<Produto> options, Context context) {
//        super(options);
//        this.context = context;
//    }
//
//    @Override
//    protected void onBindViewHolder(@NonNull SearchModelViewHolder holder, int i, @NonNull Produto model) {
//        holder.plantName.setText(model.getNomeplant());
//        holder.priceName.setText(model.getPriceplant());
//    }
//
//    @NonNull
//    @Override
//    public SearchModelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.search_recycler_row, parent, false);
//        return new SearchModelViewHolder(view);
//    }
//
//    public class SearchModelViewHolder extends RecyclerView.ViewHolder{
//        TextView plantName;
//        TextView priceName;
//        ImageView plantImage;
//        public SearchModelViewHolder(@NonNull View itemView) {
//            super(itemView);
//            plantName = itemView.findViewById(R.id.search_plant_name);
//            priceName = itemView.findViewById(R.id.price_search_text);
//            plantImage = itemView.findViewById(R.id.search_product_image);
//        }
//    }
//}
