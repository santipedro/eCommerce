package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CadastroForm extends AppCompatActivity {

    // Declaração de variáveis da classe
    private EditText edit_nome, email_cadastro, senha_cadastro;
    private Button button_cadastro;
    private String userID;
    String[] messages = {"Preencha todos os campos", "Cadastro concluído com sucesso"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_form);

        // Inicializar componentes
        IniciarComponents();

        // Definindo o listener de clique para o botão de cadastro
        button_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edit_nome.getText().toString();
                String email = email_cadastro.getText().toString();
                String senha = senha_cadastro.getText().toString();

                // Verificando se algum campo está vazio
                if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(v, messages[0], Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                } else {
                    // Chamando o método para cadastrar o usuário
                    CadastrarUser(v);
                }
            }
        });

    }

    // Método para criar uma nova conta de usuário
    private void CadastrarUser(View v) {
        String email = email_cadastro.getText().toString();
        String senha = senha_cadastro.getText().toString();

        // Criando uma nova conta de usuário com email e senha
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Conta de usuário criada com sucesso, salvando os dados do usuário
                            SaveUserData();
                            Snackbar snackbar = Snackbar.make(v, messages[1], Snackbar.LENGTH_SHORT);
                            snackbar.setBackgroundTint(Color.WHITE);
                            snackbar.setTextColor(Color.BLACK);
                            snackbar.show();
                        } else {
                            String error;

                            try {
                                // Capturando exceções específicas para melhor tratamento de erro
                                throw task.getException();

                            } catch (FirebaseAuthWeakPasswordException e) {
                                error = "Insira no mínimo 6 caracteres!";

                            } catch (FirebaseAuthUserCollisionException e) {
                                error = "Este e-mail já foi cadastrado!";

                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                error = "E-mail inserido de forma incorreta!";

                            } catch (Exception e){
                                error = "Erro no cadastro de novo usuário, digite novamente!";

                            }
                            // Exibindo o Snackbar com a mensagem de erro
                            Snackbar snackbar = Snackbar.make(v, error, Snackbar.LENGTH_SHORT);
                            snackbar.setBackgroundTint(Color.WHITE);
                            snackbar.setTextColor(Color.BLACK);
                            snackbar.show();
                        }
                    }
                });
    }

    // Método para salvar os dados do usuário no Firestore
    private void SaveUserData() {
        String nome = edit_nome.getText().toString();

        FirebaseFirestore database = FirebaseFirestore.getInstance();
        Map<String, Object> users = new HashMap<>();

        userID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Criação de um Log para registrar e verificar se o usuário foi salvo no banco de dados
        DocumentReference docReference = database.collection("Users").document(userID);
        docReference.set(users).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.d("database", "Dados salvos com sucesso!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("database_error", "Erro ao salvar os dados!");
                    }
                });
    }

    // Método para inicializar os componentes da interface gráfica
    private void IniciarComponents() {
        edit_nome = findViewById(R.id.edit_nome);
        email_cadastro = findViewById(R.id.email_cadastro);
        senha_cadastro = findViewById(R.id.senha_cadastro);
        button_cadastro = findViewById(R.id.button_cadastro);
    }

    // Método para abrir a tela de login
    public void TelaLogin(View view) {
        Intent in = new Intent(CadastroForm.this, LoginForm.class);
        startActivity(in);
    }
}
