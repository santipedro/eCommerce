package com.example.ecommerce.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.databinding.ProductItemBinding;
import com.example.ecommerce.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class PlantAdapter extends RecyclerView.Adapter<PlantAdapter.PlantViewHolder> {

    private List<Produto> plantList;  // Alterado de ArrayList para List para maior flexibilidade
    private List<Produto> originalList; // Para armazenar a lista original para filtragem
    private final Context context;

    public PlantAdapter(List<Produto> plantList, Context context) {
        this.plantList = plantList;
        this.originalList = new ArrayList<>(plantList);  // Inicializa a lista original
        this.context = context;
    }

    @NonNull
    @Override
    public PlantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //Método para criar um novo ViewHolder
        ProductItemBinding itemBinding = ProductItemBinding.inflate(LayoutInflater.from(context), parent, false); // Infla o layout do item de produto
        return new PlantViewHolder(itemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull PlantViewHolder holder, int position) {
        Produto produto = plantList.get(position);
        holder.binding.imgplant.setBackgroundResource(produto.getImgplant()); // O adapter resgata cada produto e "seta" nos seus respectivos nomes/preços etc.
        holder.binding.txtImg.setText(produto.getNomeplant());
        holder.binding.descImg.setText(produto.getDescplant());
        holder.binding.txtPreco.setText(produto.getPriceplant()); // Supondo que o preço já esteja formatado como String
    }

    @Override
    public int getItemCount() { // Método para obter o número de itens na lista
        return plantList.size(); // Retorna o tamanho da lista de produtos
    }

    public void setFilteredList(List<Produto> filteredList) { // Método para definir uma lista filtrada de produtos
        this.plantList = new ArrayList<>(filteredList);
        notifyDataSetChanged();
    }

    public static class PlantViewHolder extends RecyclerView.ViewHolder {

        ProductItemBinding binding; // Método para definir uma lista filtrada de produtos

        public PlantViewHolder(ProductItemBinding binding) {
            super(binding.getRoot()); // Chama o construtor da superclasse com a raiz do layout
            this.binding = binding;
        }
    }
}
