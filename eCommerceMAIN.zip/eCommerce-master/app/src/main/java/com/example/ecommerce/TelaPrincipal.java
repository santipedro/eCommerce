package com.example.ecommerce;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.Adapter.PlantAdapter;
import com.example.ecommerce.databinding.ActivityTelaPrincipalBinding;
import com.example.ecommerce.model.Produto;
import com.example.ecommerce.model.SearchPlant;

import java.util.ArrayList;
import java.util.List;

public class TelaPrincipal extends AppCompatActivity {

    // Declarando variáveis de classe
    private ActivityTelaPrincipalBinding binding; // Variável de binding para acessar o layout
    private PlantAdapter plantAdapter;
    private TelaPrincipal telaPrincipal;
    private ArrayList<Produto> plantList = new ArrayList(); // Lista de produtos (plantas)
    private List<Produto> produtoList;
    private ImageButton imageButton;
    private EditText searchText;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        produtoList = new ArrayList<>();

        // Inicializa o binding com o layout da Activity
        binding = ActivityTelaPrincipalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configura o RecyclerView
        RecyclerView recyclerViewPlant = binding.recyclerviewPlant;
        recyclerViewPlant.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPlant.setHasFixedSize(true);

        // Inicializa o adaptador e define no RecyclerView
        plantAdapter = new PlantAdapter(plantList, this);
        recyclerViewPlant.setAdapter(plantAdapter); // Exibe a lista de plantas no RecyclerView

        // Inicializa os componentes de pesquisa
        searchText = findViewById(R.id.text_search_main);
        imageButton = findViewById(R.id.search_button);
        imageButton.setOnClickListener(v -> performSearch()); // Define o listener do botão de pesquisa

        // Carrega a lista de plantas
        getPlant();
    }

    // Método para obter e adicionar plantas à lista
    private void getPlant() {

        // Adiciona plantas à lista
        Produto planta1 = new Produto(
                R.drawable.suculenta,
                "Planta",
                "Suculenta",
                "R$ 30,00"
        );
        plantList.add(planta1);

        Produto planta2 = new Produto(
                R.drawable.tulipa,
                "Flor",
                "Tulipa",
                "R$ 50,00"
        );
        plantList.add(planta2);

        Produto planta3 = new Produto(
                R.drawable.lirio,
                "Flor",
                "Lírio",
                "R$ 40,00"
        );
        plantList.add(planta3);

        Produto planta4 = new Produto(
                R.drawable.samambaia,
                "Planta",
                "Samambaia",
                "R$ 100,00"
        );
        plantList.add(planta4);

        Produto planta5 = new Produto(
                R.drawable.espadastjorge,
                "Planta",
                "Espada-de-São-Jorge",
                "R$ 100,00"
        );
        plantList.add(planta5);

        Produto planta6 = new Produto(
                R.drawable.orquidea,
                "Flor",
                "Orquídea",
                "R$ 35,00"
        );
        plantList.add(planta6);
    }

    // Método para realizar a pesquisa
    private void performSearch() {
        String query = searchText.getText().toString().toLowerCase().trim();

        if (query.isEmpty()) {
            // Se o campo de pesquisa estiver vazio, exibe uma mensagem
            Toast.makeText(this, "Digite um termo para pesquisar", Toast.LENGTH_SHORT).show();
        } else {
            // Filtra a lista de produtos com base no termo de pesquisa
            ArrayList<Produto> filteredList = new ArrayList<>();

            for (Produto produto : produtoList) {
                if (produto.getNomeplant().toLowerCase().contains(query)) {
                    filteredList.add(produto);
                }
            }

            // Atualiza a lista filtrada no adaptador
            plantAdapter.setFilteredList(filteredList);

            if (filteredList.isEmpty()) {
                // Exibe uma mensagem se nenhum resultado for encontrado
                Toast.makeText(this, "Nenhum resultado encontrado para '" + query + "'", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

