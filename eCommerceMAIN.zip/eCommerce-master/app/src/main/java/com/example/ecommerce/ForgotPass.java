package com.example.ecommerce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ecommerce.Utils.ConfigBD;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPass extends AppCompatActivity {

    private EditText forgot_email;
    private Button button_forgot;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        auth = ConfigBD.FirebaseAuthentic();
        iniciarComponents();
    }

    public void recoverySenha(View view){

        String email = forgot_email.getText().toString();

        if(!email.isEmpty()){ // Verifica se o campo email de recuperação não está vazio
            sendEmail(email);
        }else{
            Toast.makeText(this, "Digite o email para recuperação de senha!", Toast.LENGTH_SHORT).show();
            // Exibe mensagem se o campo email de recuperação estiver vazio
        }

    }

    private void sendEmail(String email){
        auth.sendPasswordResetEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(ForgotPass.this, "Enviamos o link de redefinir senha para o seu email!", Toast.LENGTH_SHORT).show();
                // Exibe uma mensagem para confirmação de redefinição de senha via email
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(ForgotPass.this, "Erro ao enviar email!", Toast.LENGTH_SHORT).show();
                // Exibe uma mensagem de erro

            }
        });
    }

    private void iniciarComponents(){
        forgot_email = findViewById(R.id.email_forgot);
        button_forgot = findViewById(R.id.button_forgot);
    }

    // Método para voltar a tela de login
    public void TelaLogin(View view) {
        Intent in = new Intent(ForgotPass.this, LoginForm.class);
        startActivity(in);
    }
}
